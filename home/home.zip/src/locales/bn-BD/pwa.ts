export default {
  'app.pwa.offline': 'আপনি এখন অফলাইন',
  'app.pwa.serviceworker.updated': 'নতুন সামগ্রী উপলব্ধ',
  'app.pwa.serviceworker.updated.hint':
    'বর্তমান পৃষ্ঠাটি পুনরায় লোড করতে দয়া করে "রিফ্রেশ" বোতাম টিপুন',
  'app.pwa.serviceworker.updated.ok': 'রিফ্রেশ',
};
