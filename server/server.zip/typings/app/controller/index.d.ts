// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportAlert = require('../../../app/controller/alert');
import ExportAlertrule = require('../../../app/controller/alertrule');
import ExportBaseController = require('../../../app/controller/base_controller');
import ExportCompany = require('../../../app/controller/company');
import ExportFilterOfTimestamps = require('../../../app/controller/filterOfTimestamps');
import ExportFlow = require('../../../app/controller/flow');
import ExportHome = require('../../../app/controller/home');
import ExportInterfacedata = require('../../../app/controller/interfacedata');
import ExportJetty = require('../../../app/controller/jetty');
import ExportLoginlog = require('../../../app/controller/loginlog');
import ExportOperlog = require('../../../app/controller/operlog');
import ExportPermission = require('../../../app/controller/permission');
import ExportProducttype = require('../../../app/controller/producttype');
import ExportReport = require('../../../app/controller/report');
import ExportReportTemplate = require('../../../app/controller/reportTemplate');
import ExportRole = require('../../../app/controller/role');
import ExportRolepermission = require('../../../app/controller/rolepermission');
import ExportSysconfig = require('../../../app/controller/sysconfig');
import ExportSystem = require('../../../app/controller/system');
import ExportTransaction = require('../../../app/controller/transaction');
import ExportTransactionevent = require('../../../app/controller/transactionevent');
import ExportTransactioneventlog = require('../../../app/controller/transactioneventlog');
import ExportUpload = require('../../../app/controller/upload');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    alert: ExportAlert;
    alertrule: ExportAlertrule;
    baseController: ExportBaseController;
    company: ExportCompany;
    filterOfTimestamps: ExportFilterOfTimestamps;
    flow: ExportFlow;
    home: ExportHome;
    interfacedata: ExportInterfacedata;
    jetty: ExportJetty;
    loginlog: ExportLoginlog;
    operlog: ExportOperlog;
    permission: ExportPermission;
    producttype: ExportProducttype;
    report: ExportReport;
    reportTemplate: ExportReportTemplate;
    role: ExportRole;
    rolepermission: ExportRolepermission;
    sysconfig: ExportSysconfig;
    system: ExportSystem;
    transaction: ExportTransaction;
    transactionevent: ExportTransactionevent;
    transactioneventlog: ExportTransactioneventlog;
    upload: ExportUpload;
    user: ExportUser;
  }
}
