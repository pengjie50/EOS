// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportCheckToken = require('../../../app/middleware/checkToken');
import ExportErrorHandler = require('../../../app/middleware/error_handler');
import ExportWhere = require('../../../app/middleware/where');

declare module 'egg' {
  interface IMiddleware {
    checkToken: typeof ExportCheckToken;
    errorHandler: typeof ExportErrorHandler;
    where: typeof ExportWhere;
  }
}
