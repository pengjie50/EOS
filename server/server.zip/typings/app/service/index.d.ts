// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportAlert = require('../../../app/service/alert');
import ExportAlertrule = require('../../../app/service/alertrule');
import ExportBaseService = require('../../../app/service/base_service');
import ExportCompany = require('../../../app/service/company');
import ExportFlow = require('../../../app/service/flow');
import ExportInterfacedata = require('../../../app/service/interfacedata');
import ExportJetty = require('../../../app/service/jetty');
import ExportLoginlog = require('../../../app/service/loginlog');
import ExportOperlog = require('../../../app/service/operlog');
import ExportPermission = require('../../../app/service/permission');
import ExportReport = require('../../../app/service/report');
import ExportRole = require('../../../app/service/role');
import ExportRolepermission = require('../../../app/service/rolepermission');
import ExportSysconfig = require('../../../app/service/sysconfig');
import ExportSystem = require('../../../app/service/system');
import ExportTool = require('../../../app/service/tool');
import ExportTransaction = require('../../../app/service/transaction');
import ExportTransactionevent = require('../../../app/service/transactionevent');
import ExportTransactioneventlog = require('../../../app/service/transactioneventlog');
import ExportUser = require('../../../app/service/user');
import ExportUserconfig = require('../../../app/service/userconfig');

declare module 'egg' {
  interface IService {
    alert: AutoInstanceType<typeof ExportAlert>;
    alertrule: AutoInstanceType<typeof ExportAlertrule>;
    baseService: AutoInstanceType<typeof ExportBaseService>;
    company: AutoInstanceType<typeof ExportCompany>;
    flow: AutoInstanceType<typeof ExportFlow>;
    interfacedata: AutoInstanceType<typeof ExportInterfacedata>;
    jetty: AutoInstanceType<typeof ExportJetty>;
    loginlog: AutoInstanceType<typeof ExportLoginlog>;
    operlog: AutoInstanceType<typeof ExportOperlog>;
    permission: AutoInstanceType<typeof ExportPermission>;
    report: AutoInstanceType<typeof ExportReport>;
    role: AutoInstanceType<typeof ExportRole>;
    rolepermission: AutoInstanceType<typeof ExportRolepermission>;
    sysconfig: AutoInstanceType<typeof ExportSysconfig>;
    system: AutoInstanceType<typeof ExportSystem>;
    tool: AutoInstanceType<typeof ExportTool>;
    transaction: AutoInstanceType<typeof ExportTransaction>;
    transactionevent: AutoInstanceType<typeof ExportTransactionevent>;
    transactioneventlog: AutoInstanceType<typeof ExportTransactioneventlog>;
    user: AutoInstanceType<typeof ExportUser>;
    userconfig: AutoInstanceType<typeof ExportUserconfig>;
  }
}
