// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportAlert = require('../../../app/model/alert');
import ExportAlertrule = require('../../../app/model/alertrule');
import ExportAlertruleTransaction = require('../../../app/model/alertrule_transaction');
import ExportAlertUserRead = require('../../../app/model/alert_user_read');
import ExportCompany = require('../../../app/model/company');
import ExportFlow = require('../../../app/model/flow');
import ExportJetty = require('../../../app/model/jetty');
import ExportLoginlog = require('../../../app/model/loginlog');
import ExportOperlog = require('../../../app/model/operlog');
import ExportPermission = require('../../../app/model/permission');
import ExportProducttype = require('../../../app/model/producttype');
import ExportReport = require('../../../app/model/report');
import ExportRole = require('../../../app/model/role');
import ExportRolepermission = require('../../../app/model/rolepermission');
import ExportSysconfig = require('../../../app/model/sysconfig');
import ExportTerminal = require('../../../app/model/terminal');
import ExportTransaction = require('../../../app/model/transaction');
import ExportTransactionevent = require('../../../app/model/transactionevent');
import ExportUser = require('../../../app/model/user');
import ExportUserconfig = require('../../../app/model/userconfig');

declare module 'egg' {
  interface IModel {
    Alert: ReturnType<typeof ExportAlert>;
    Alertrule: ReturnType<typeof ExportAlertrule>;
    AlertruleTransaction: ReturnType<typeof ExportAlertruleTransaction>;
    AlertUserRead: ReturnType<typeof ExportAlertUserRead>;
    Company: ReturnType<typeof ExportCompany>;
    Flow: ReturnType<typeof ExportFlow>;
    Jetty: ReturnType<typeof ExportJetty>;
    Loginlog: ReturnType<typeof ExportLoginlog>;
    Operlog: ReturnType<typeof ExportOperlog>;
    Permission: ReturnType<typeof ExportPermission>;
    Producttype: ReturnType<typeof ExportProducttype>;
    Report: ReturnType<typeof ExportReport>;
    Role: ReturnType<typeof ExportRole>;
    Rolepermission: ReturnType<typeof ExportRolepermission>;
    Sysconfig: ReturnType<typeof ExportSysconfig>;
    Terminal: ReturnType<typeof ExportTerminal>;
    Transaction: ReturnType<typeof ExportTransaction>;
    Transactionevent: ReturnType<typeof ExportTransactionevent>;
    User: ReturnType<typeof ExportUser>;
    Userconfig: ReturnType<typeof ExportUserconfig>;
  }
}
